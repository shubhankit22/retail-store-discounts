package com.store.discounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscountsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.store.discounts.entity;

import java.util.ArrayList;
import java.util.List;

public class Bill {

	User user;
	
	List<BillItem> billItems = new ArrayList<>();
	
	long amount;
	
	long discount;

	long finalAmount;

	public long getDiscount() {
		return discount;
	}

	public void setDiscount(long discount) {
		this.discount = discount;
	}

	public long getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(long finalAmount) {
		this.finalAmount = finalAmount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<BillItem> getBillItems() {
		return billItems;
	}

	public void setBillItems(List<BillItem> billItems) {
		this.billItems = billItems;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}
	
}

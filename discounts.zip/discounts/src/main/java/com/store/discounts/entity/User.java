package com.store.discounts.entity;

import java.time.LocalDate;

public class User {

	long userId;
	
	long empId;
	
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	String name;
	
	boolean affiliateMember;
	
	LocalDate firstBillDate;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isAffiliateMember() {
		return affiliateMember;
	}

	public void setAffiliateMember(boolean affiliateMember) {
		this.affiliateMember = affiliateMember;
	}

	public LocalDate getFirstBillDate() {
		return firstBillDate;
	}

	public void setFirstBillDate(LocalDate firstBillDate) {
		this.firstBillDate = firstBillDate;
	}
	
	
}

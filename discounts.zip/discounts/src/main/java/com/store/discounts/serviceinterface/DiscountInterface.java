package com.store.discounts.serviceinterface;

import com.store.discounts.entity.Bill;

public interface DiscountInterface {
	public long calculateDiscount(Bill bill);
}

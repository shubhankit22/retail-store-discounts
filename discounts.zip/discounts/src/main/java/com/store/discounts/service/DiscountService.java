package com.store.discounts.service;

import org.springframework.stereotype.Service;

import com.store.discounts.entity.Bill;
import com.store.discounts.serviceinterface.DiscountInterface;
import com.store.discounts.utility.DiscountUtility;

@Service
public class DiscountService implements DiscountInterface {

	@Override
	public long calculateDiscount(Bill bill) {
		
		long applicableAmount = DiscountUtility.getApplicableBillAmounts(bill.getBillItems(), bill);
		
		long applicableDiscountPercentage = DiscountUtility.getApplicableDiscountPercentage(bill.getUser());
		
		long cashDiscount = DiscountUtility.getCashDiscount(bill.getAmount());
		
		double percentageDiscount = (double)(applicableAmount * applicableDiscountPercentage)/100;
		
		bill.setFinalAmount(Math.round(bill.getAmount() - cashDiscount - percentageDiscount));
		
		return bill.getFinalAmount();
	}

}

package com.store.discounts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.store.discounts.entity.Bill;
import com.store.discounts.serviceinterface.DiscountInterface;

@RestController
public class DiscountController {

	@Autowired
	DiscountInterface discountInterface;
	
	@PostMapping(value="/getBillAmount")
	public long calculateDiscount(@RequestBody Bill bill) {
		return discountInterface.calculateDiscount(bill);
	}
	
}

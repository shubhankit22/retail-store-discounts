package com.store.discounts.utility;

import java.time.LocalDate;
import java.util.List;

import com.store.discounts.configuration.ApplicationContextUtils;
import com.store.discounts.configuration.PropertiesConfig;
import com.store.discounts.entity.Bill;
import com.store.discounts.entity.BillItem;
import com.store.discounts.entity.User;

public class DiscountUtility {
	
	private static final boolean EMPLOYEE_VALID = Boolean.TRUE;
	
	private DiscountUtility() {}
	
	public static long getApplicableBillAmounts(List<BillItem> billItems, Bill bill) {
		
		PropertiesConfig propertiesConfig = ApplicationContextUtils.getApplicationContext().getBean(PropertiesConfig.class);
		
		long applicableAmount = 0;
		long totalAmount = 0;
		
		List<Object> exemptedCategories = propertiesConfig.getExemptedCategories();
		
		for(BillItem billItem: billItems) {
			
			totalAmount += (billItem.getPrice() * billItem.getQuatity());
			
			if(!exemptedCategories.contains(billItem.getCategory())){
				applicableAmount += (billItem.getPrice() * billItem.getQuatity());
			}
		}
		
		bill.setAmount(totalAmount);
		return applicableAmount;
	}

	public static long getApplicableDiscountPercentage(User user) {
	
		PropertiesConfig propertiesConfig = ApplicationContextUtils.getApplicationContext().getBean(PropertiesConfig.class);
		
		LocalDate currentDate = LocalDate.now();
		LocalDate loyaltyApplicableOn = user.getFirstBillDate().plusYears(propertiesConfig.getLoyaltyPeriod());
		
		if(user.getEmpId() != 0L && EMPLOYEE_VALID) {
			return propertiesConfig.getEmployeeDiscount();
		}
		else if(user.isAffiliateMember()) {
			return propertiesConfig.getMembershipDiscount();
		}
		else if(loyaltyApplicableOn.isBefore(currentDate)) {
			return propertiesConfig.getLoyaltyDiscount();
		}
		else {
			return 0;
		}
		
	}

	public static long getCashDiscount(long amount) {
		
		PropertiesConfig propertiesConfig = ApplicationContextUtils.getApplicationContext().getBean(PropertiesConfig.class);
		
		return (amount/propertiesConfig.getRecurringAmountForDiscount())
				*propertiesConfig.getAmountBasedDiscount();
	}

}

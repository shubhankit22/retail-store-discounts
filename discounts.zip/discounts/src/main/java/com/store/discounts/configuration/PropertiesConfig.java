package com.store.discounts.configuration;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertiesConfig {

	@Value("${categories.exempt.from.discount}")
	private String exemptedCategories;

	@Value("${loyalty.period.in.years}")
	private long loyaltyPeriod;

	@Value("${employee.discount}")
	private long employeeDiscount;

	@Value("${membership.discount}")
	private long membershipDiscount;

	@Value("${loyalty.discount}")
	private long loyaltyDiscount;

	@Value("${amount.based.discount}")
	private long amountBasedDiscount;

	@Value("${recurring.amount.for.discount}")
	private long recurringAmountForDiscount;
	
	public List<Object> getExemptedCategories() {
		return Arrays.asList(exemptedCategories.split(","));
	}

	public long getLoyaltyPeriod() {
		return loyaltyPeriod;
	}

	public long getEmployeeDiscount() {
		return employeeDiscount;
	}

	public long getMembershipDiscount() {
		return membershipDiscount;
	}

	public long getLoyaltyDiscount() {
		return loyaltyDiscount;
	}

	public long getAmountBasedDiscount() {
		return amountBasedDiscount;
	}

	public long getRecurringAmountForDiscount() {
		return recurringAmountForDiscount;
	}

}
